extends Node2D

const WORLD_WIDTH := 2400.0
const GROUND_Y := 430.0
const PLAYER_W := 34.0
const PLAYER_H := 72.0
const GRAVITY := 1500.0
const JUMP_VELOCITY := -590.0

var player_x := 150.0
var player_y := GROUND_Y
var velocity_y := 0.0
var camera_x := 0.0
var score := 0
var tickets: Array[Vector2] = []
var luggage: Array[Rect2] = []
var game_over := false
var touch_left := false
var touch_right := false
var touch_jump := false
var train_offset := 0.0
var message_timer := 0.0

func _ready() -> void:
    _reset_level()

func _reset_level() -> void:
    player_x = 150.0
    player_y = GROUND_Y
    velocity_y = 0.0
    camera_x = 0.0
    score = 0
    game_over = false
    message_timer = 0.0
    tickets = [
        Vector2(420, 365), Vector2(620, 330), Vector2(820, 365),
        Vector2(1110, 350), Vector2(1320, 320), Vector2(1570, 360),
        Vector2(1840, 335), Vector2(2110, 360)
    ]
    luggage = [
        Rect2(700, GROUND_Y - 26, 42, 26),
        Rect2(1200, GROUND_Y - 30, 48, 30),
        Rect2(1740, GROUND_Y - 25, 40, 25)
    ]

func _process(delta: float) -> void:
    if game_over:
        queue_redraw()
        return

    var direction := 0.0
    if Input.is_action_pressed("ui_left") or touch_left:
        direction -= 1.0
    if Input.is_action_pressed("ui_right") or touch_right:
        direction += 1.0

    player_x = clampf(player_x + direction * 310.0 * delta, 25.0, WORLD_WIDTH - 40.0)

    var wants_jump := Input.is_action_just_pressed("ui_accept") or touch_jump
    if wants_jump and player_y >= GROUND_Y - 0.5:
        velocity_y = JUMP_VELOCITY
    touch_jump = false

    velocity_y += GRAVITY * delta
    player_y += velocity_y * delta
    if player_y > GROUND_Y:
        player_y = GROUND_Y
        velocity_y = 0.0

    for i in range(tickets.size() - 1, -1, -1):
        if absf(player_x - tickets[i].x) < 38.0 and absf((player_y - 42.0) - tickets[i].y) < 48.0:
            tickets.remove_at(i)
            score += 10

    var player_rect := Rect2(player_x - PLAYER_W * 0.5, player_y - PLAYER_H, PLAYER_W, PLAYER_H)
    for bag in luggage:
        if player_rect.intersects(bag) and player_y >= GROUND_Y - 1.0:
            message_timer += delta
            if message_timer > 0.45:
                game_over = true

    camera_x = clampf(player_x - 300.0, 0.0, WORLD_WIDTH - 960.0)
    train_offset = fposmod(train_offset + 90.0 * delta, 1500.0)
    queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        _handle_touch(event.position, event.pressed)
    elif event is InputEventScreenDrag:
        _update_touch(event.position)

func _handle_touch(pos: Vector2, pressed: bool) -> void:
    var p := _screen_to_design(pos)
    if not pressed:
        touch_left = false
        touch_right = false
        touch_jump = false
        return
    if p.y > 445.0:
        if p.x < 320.0:
            touch_left = true
        elif p.x < 640.0:
            touch_right = true
        else:
            touch_jump = true
    if game_over and Rect2(330, 285, 300, 70).has_point(p):
        _reset_level()

func _update_touch(pos: Vector2) -> void:
    var p := _screen_to_design(pos)
    touch_left = p.y > 445.0 and p.x < 320.0
    touch_right = p.y > 445.0 and p.x >= 320.0 and p.x < 640.0

func _screen_to_design(pos: Vector2) -> Vector2:
    var size := get_viewport_rect().size
    return Vector2(pos.x * 960.0 / size.x, pos.y * 540.0 / size.y)

func _draw() -> void:
    draw_rect(Rect2(0, 0, 960, 540), Color("#101b2b"))
    _draw_skyline()
    _draw_train()
    _draw_station()
    _draw_world_items()
    _draw_player()
    _draw_hud()
    if game_over:
        _draw_game_over()

func _draw_skyline() -> void:
    for i in range(12):
        var x := float(i * 105) - fposmod(camera_x * 0.18, 1260.0)
        var h := 90.0 + float((i * 37) % 90)
        draw_rect(Rect2(x, 270.0 - h, 76.0, h), Color("#26384b"))
        for wy in range(3):
            for wx in range(3):
                draw_rect(Rect2(x + 12 + wx * 19, 285 - h + wy * 24, 8, 11), Color("#d7b978", 0.35))

func _draw_train() -> void:
    var train_x := 470.0 - fposmod(train_offset, 1500.0)
    for i in range(4):
        var x := train_x + i * 210.0
        draw_rect(Rect2(x, 300, 205, 78), Color("#d9e0e6"))
        draw_rect(Rect2(x, 348, 205, 12), Color("#c13c42"))
        for wx in range(3):
            draw_rect(Rect2(x + 18 + wx * 60, 313, 48, 23), Color("#23384b"))
        draw_circle(Vector2(x + 42, 381), 10, Color("#18212c"))
        draw_circle(Vector2(x + 165, 381), 10, Color("#18212c"))

func _draw_station() -> void:
    draw_rect(Rect2(0, GROUND_Y, 960, 110), Color("#4c535b"))
    draw_rect(Rect2(0, GROUND_Y, 960, 8), Color("#d5d9dc"))
    draw_rect(Rect2(0, GROUND_Y + 12, 960, 5), Color("#e8bd54"))
    for i in range(22):
        var x := float(i * 55) - fposmod(camera_x, 55.0)
        draw_line(Vector2(x, GROUND_Y + 38), Vector2(x + 30, GROUND_Y + 38), Color("#69727a"), 2)

func _draw_world_items() -> void:
    for ticket in tickets:
        var p := Vector2(ticket.x - camera_x, ticket.y)
        if p.x > -30 and p.x < 990:
            draw_rect(Rect2(p.x - 12, p.y - 9, 24, 18), Color("#f4d06f"))
            draw_line(Vector2(p.x - 5, p.y), Vector2(p.x + 5, p.y), Color("#6c5122"), 2)
    for bag in luggage:
        var r := Rect2(bag.position.x - camera_x, bag.position.y, bag.size.x, bag.size.y)
        if r.position.x > -60 and r.position.x < 1000:
            draw_rect(r, Color("#b56d3d"))
            draw_rect(Rect2(r.position.x + 8, r.position.y + 7, r.size.x - 16, 4), Color("#e2b27d"))

func _draw_player() -> void:
    var x := player_x - camera_x
    var y := player_y
    draw_circle(Vector2(x, GROUND_Y + 1), 13, Color("#20252a"))
    draw_line(Vector2(x - 5, y - 27), Vector2(x - 11, y - 4), Color("#263d58"), 8)
    draw_line(Vector2(x + 5, y - 27), Vector2(x + 11, y - 4), Color("#263d58"), 8)
    draw_line(Vector2(x - 7, y - 48), Vector2(x + 8, y - 29), Color("#263d58"), 7)
    draw_line(Vector2(x + 7, y - 48), Vector2(x + 14, y - 32), Color("#263d58"), 7)
    draw_rect(Rect2(x - 11, y - 62, 22, 34), Color("#e2e7eb"))
    draw_circle(Vector2(x, y - 72), 11, Color("#d7a47f"))
    draw_arc(Vector2(x, y - 74), 11, PI, TAU, 16, Color("#29313a"), 5)

func _draw_hud() -> void:
    draw_string(ThemeDB.fallback_font, Vector2(24, 38), "RAIL LIFE 2D", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(24, 66), "БИЛЕТЫ: %d" % score, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#f4d06f"))
    draw_string(ThemeDB.fallback_font, Vector2(690, 38), "БЕЗОПАСНАЯ ЗОНА СТАНЦИИ", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("#c7d3df"))
    _draw_control_button(Rect2(28, 465, 110, 58), "◀")
    _draw_control_button(Rect2(155, 465, 110, 58), "▶")
    _draw_control_button(Rect2(820, 465, 112, 58), "ПРЫЖОК")

func _draw_control_button(rect: Rect2, label: String) -> void:
    draw_rect(rect, Color("#35516b"))
    draw_string(ThemeDB.fallback_font, rect.position + Vector2(0, 37), label, HORIZONTAL_ALIGNMENT_CENTER, rect.size.x, 24, Color.WHITE)

func _draw_game_over() -> void:
    draw_rect(Rect2(0, 0, 960, 540), Color(0, 0, 0, 0.72))
    draw_string(ThemeDB.fallback_font, Vector2(0, 220), "ПОПРОБУЙ ЕЩЁ РАЗ", HORIZONTAL_ALIGNMENT_CENTER, 960, 34, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(0, 260), "Собрано билетов: %d" % score, HORIZONTAL_ALIGNMENT_CENTER, 960, 20, Color("#f4d06f"))
    draw_rect(Rect2(330, 285, 300, 70), Color("#35516b"))
    draw_string(ThemeDB.fallback_font, Vector2(0, 329), "ЗАНОВО", HORIZONTAL_ALIGNMENT_CENTER, 960, 24, Color.WHITE)
